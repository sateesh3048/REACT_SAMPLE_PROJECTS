import React from "react";
import {Row, Col} from "reactstrap";

const Footer = () => (
  <footer className="footer fixed-bottom">
    <Row>
      
    </Row>
    <div className="text-center bg-secondary">
        &copy;2017.  Copy rights reserved
    </div>
  </footer>
);
export default Footer;