import React from "react";
import RoutesList from '../../../routes';


const Main = () => (
  <div className="container">
    <RoutesList />
  </div>
)
export default Main;