import React from "react";
const Support = () => (
  <div className="row">
    <div className="col-sm-12 text-center">
      <p>Please send us mail for any support</p>
    </div>
  </div>
)
export default Support;


