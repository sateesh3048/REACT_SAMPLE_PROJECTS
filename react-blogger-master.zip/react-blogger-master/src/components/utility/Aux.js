import React from "react";
const Aux = (props) => props.children;
export default Aux;
