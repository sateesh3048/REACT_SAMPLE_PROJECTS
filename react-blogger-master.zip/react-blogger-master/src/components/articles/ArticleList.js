import React from "react";
import ArticleRow from './ArticleRow';
import Aux from '../../components/utility/Aux';

const ArticleList = (props) => {
  let articlesUI = null;
  if(props.error){
    articlesUI = (<div className="row">
        <div className="col-sm-12">
          <h3 className="text-center text-danger">{props.error.toString()}</h3>
        </div>
      </div>)
  }else if(props.isLoading){
    articlesUI = (
      <div className="row">
        <div className="col-sm-12">
          <h3 className="text-center">Articles are loading please wait!</h3>
        </div>
      </div>
    )
  }else{
   articlesUI = (
    <Aux>
      <ul className="list-group">
        {
          props.articles.map(article => {
            return (
              <ArticleRow key={article.id} article={article} />
            )
          })
        }
      </ul>
    </Aux>
   )
  }
  return(
  <Aux>
     {articlesUI}
  </Aux>
  )
};

export default ArticleList;