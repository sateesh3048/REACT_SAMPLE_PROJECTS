import React, {Component} from "react";
import Header from './Header/Header';
import Footer from '../../components/layout/Footer/Footer';
import Main from '../../components/layout/Main/Main';
import Aux from '../../components/utility/Aux';

class Layout extends Component {
    render(){
        return(
          <Aux>
              <Header />
              <Main />
              <Footer />
          </Aux>
        )
    }
}

export default Layout;