import React from "react";
import classes from "./Cockpit.css";
import Aux from '../../hoc/aux';

const cockpit = (props) => {

    const assingedClasses = [];
    let btnStyle = [classes.Button];
    
    if(props.canShowPersons){
      btnStyle.push(classes.Red);
    }

    if(props.persons.length <= 2){
      assingedClasses.push(classes.red);
    }

    if(props.persons.length <=1){
      assingedClasses.push(classes.bold);
    }
    

  return (
        <Aux>
          <h1> I am react App </h1>
            <p className = {assingedClasses.join(' ')} >This is really working</p>
            <button
              className = { btnStyle.join(' ') } 
              onClick = { props.clicked }
            >Show/Hide Persons
            </button>
        </Aux>
  )  
}

export default cockpit;