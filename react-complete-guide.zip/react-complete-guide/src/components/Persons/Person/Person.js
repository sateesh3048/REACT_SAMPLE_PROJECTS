import React from 'react';
import styles from "./Person.css";
import PropTypes from 'prop-types';

const person = (params) => {
 

  return(
    <div className={styles.Person}  >
      <p onClick={params.click} >My name is {params.name} with age: {params.age} </p>
      <p> {params.children} </p>
      <input type = "text" onChange={params.change} value={params.name}/>
    </div>
  )
};

person.propTypes = {
  click: PropTypes.func,
  name: PropTypes.string,
  age: PropTypes.number,
  change: PropTypes.func 
}
export default person;