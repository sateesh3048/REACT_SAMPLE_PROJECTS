import React, { Component } from "react";
import  Person  from './Person/Person';

class Persons extends Component {
  
  componentWillReceiveProps(nextProps){
    console.log("[Update Persons.js] from componentWillReceiveProps", nextProps);
  }

  shouldComponentUpdate(nextProps, nextState){
    console.log("[Update Persons.js] from shouldComponentUpdate ");
    return true;
  }

  componentDidUpdate(nextProps, nextState){
    console.log("[Update Persons.js] from componentDidUpdate");
  }

  render()  {
    console.log("[Persons.js] inside render");
    return (
            this.props.persons.map((person, index) => {
              return <Person 
              click = { () => { this.props.clicked(index) } }
              change = { (event) => {this.props.changed(event, person.id)}}
              name= {person.name} 
              age = {person.age} 
              key = {person.id} />
            })

    )
  }
  
}

export default Persons;