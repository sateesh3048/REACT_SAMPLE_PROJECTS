import React, { Component } from 'react';
import classes from './App.css';
import Persons from '../components/Persons/Persons';
import Cockpit from '../components/Cockpit/Cockpit';

class App extends Component {
  state = {
    persons: [
      {id: "1", name: "Krishna Babu1", age: 36},
      {id: "2", name: "Anji Babu", age: 34},
      {id: "3", name: "Sati Babu", age: 32}
    ],
    canShowPersons: false,
    toggleClickHandler: 0
  }
  
  togglePersonsHandler = () => {
    const doesShowPersons = this.state.canShowPersons;
    this.setState( (prevState, props) => {
      return {
        canShowPersons: !doesShowPersons,
        toggleClickHandler: prevState.toggleClickHandler + 1
      }
    });
  };

  switchNameHandler = (newName) => {
    console.log("Was clicked!");
    this.setState({
      persons:  [
      {id: 1, name: "Krishna Babu Kanikanti", age: 36},
      {id: 2, name: "Anji Babu", age: 34},
      {id: 3, name: newName, age: 32}
      
    ]
    })
  };

  nameChangedHandler = (event, id) => {
    console.log(event);
    console.log(id);
    const personIndex = this.state.persons.findIndex(p => {
      return p.id === id;
    });
    
    const person = {
      ...this.state.persons[personIndex]
    };
    
    person.name = event.target.value;
    
    const persons = [...this.state.persons];
    
    persons[personIndex] = person;
    
    this.setState({
      persons:  persons
    })
  };

  deletePersonHandler = (personIndex) => {
    const persons = [...this.state.persons];
    persons.splice(personIndex, 1);
    this.setState({persons: persons});
  };

  render() {
    let personsUI = null;
    

    if(this.state.canShowPersons){
      personsUI =  <Persons 
                    persons = {this.state.persons}
                    clicked = { this.deletePersonHandler } 
                    changed = { this.nameChangedHandler }
                   />
    }

     
   return (
        <div className={classes.App}>
            <Cockpit 
              persons = { this.state.persons }
              canShowPersons = { this.state.canShowPersons }
              clicked = { this.togglePersonsHandler } 
            />
            {personsUI}
        </div>
    );
    //return React.createElement('div', {className: 'App'}, React.createElement('h1', null, "Hi React how are u?"));
  }
}

export default App;
