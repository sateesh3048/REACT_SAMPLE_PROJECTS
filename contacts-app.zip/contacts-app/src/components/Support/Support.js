import React from "react";

const Support = () => (
  <div className="row">
    <div className="col-sm-12 text-center">
       Please contact customer support for any queries.
    </div>
  </div>
);

export default Support;