import React from "react";
import { configure, shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import Support from "./Support";
configure({adapter: new Adapter()});

describe('<Support />', () => {
  it("should render support text", () => {
    const wrapper = shallow(<Support />);
    expect(wrapper.find("Please contact customer support for any queries")).toHaveLength(1);
  })
});