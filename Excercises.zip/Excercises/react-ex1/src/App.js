import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import UserOutput from './UserOutput/UserOutput';
import UserInput from './UserInput/UserInput';

class App extends Component {
  state = {
    data: [
      { userName: "Satyam" },
      { userName: "Ravi" },
      { userName: "Raju" },
      { userName: "Yogi" }
    ]  
  }
  
  clickHandler = () => {
    this.setState({
      data: [
        { userName: "Satyam-1" },
        { userName: "Ravi-1" },
        { userName: "Raju-2" },
        { userName: "Yogi-3" }
    ]  
    })
  }

  changeHandler = (event) => {
    this.setState({
      data: [
        { userName: "Satyam" },
        { userName: event.target.value },
        { userName: "Raju-2" },
        { userName: "Yogi-3" }
      ]  
    })
  }
  render() {
    const style = {
      backgroundColor: "grey",
      border: "2px solid blue",
      cursor: "pointer"
    };
    return (
      <div className="App">
        <button 
        style = { style }
        onClick={this.clickHandler} 
        >ClickButton</button>
        <UserInput 
        userName = {this.state.data[1].userName}
        change = {this.changeHandler} />
        <UserOutput userName={this.state.data[0].userName} />
        <UserOutput userName={this.state.data[1].userName}
        
        />
        <UserOutput userName={this.state.data[2].userName}/>
        <UserOutput userName={this.state.data[3].userName}/>
      </div>
    );
  }
}

export default App;
