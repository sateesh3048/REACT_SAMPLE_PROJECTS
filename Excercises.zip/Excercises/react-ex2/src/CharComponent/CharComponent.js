import React from 'react';
import "./CharComponent.css";
const charComponent = (prop) => {
  return(<div className="CharComponent" onClick={ prop.click } >
      { prop.char }
    </div>)
}

export default charComponent;