import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ValidationComponent from './ValidationComponent/ValidationComponent';
import CharComponent from './CharComponent/CharComponent';

class App extends Component {
  
  state = {
    inputLength: 0,
    enteredChars: ""
  }

 
  updateInputText = (event) => {
    this.setState({
      inputLength: event.target.value.length,
      enteredChars: event.target.value
    })
  }

  removeChar = (event, charIndex) => {
    const chars = this.state.enteredChars.split("");
    chars.splice(charIndex, 1);
    this.setState({
      enteredChars: chars.join("")
    })
  }

  render() {
    const inputChars = this.state.enteredChars;
    const charsUi = inputChars.split("").map((char, index) => {
      return <CharComponent 
      char = { char }
      click = { (event) => this.removeChar(event, index) }
      key = { index }
      />
   })

    return (
      <div className="App">
        UserName: <input type="text" 
          name="name"
          value = { this.state.enteredChars }
          onChange = { this.updateInputText }
          
        />
        <p> input lenght: {this.state.inputLength} </p>
        <ValidationComponent length = {this.state.inputLength} />
        {charsUi}
      </div>
    );
  }
}

export default App;
