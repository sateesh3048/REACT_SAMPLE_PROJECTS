import React from 'react';

const validationComponent = (prop) => {
  if(prop.length < 5){
    return <p>Text length is too short</p>
  }else if(prop.length > 10) {
    return <p>Test length is too long </p>
  }else{
    return <p>Lenght is Good</p>
  }
};

export default validationComponent;