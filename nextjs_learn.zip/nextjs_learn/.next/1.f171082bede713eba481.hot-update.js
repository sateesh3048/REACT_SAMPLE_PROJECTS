webpackHotUpdate(1,{

/***/ 415:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__resourceQuery) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _style = __webpack_require__(413);

var _style2 = _interopRequireDefault(_style);

var _react = __webpack_require__(17);

var _react2 = _interopRequireDefault(_react);

var _link = __webpack_require__(400);

var _link2 = _interopRequireDefault(_link);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _jsxFileName = "C:\\Users\\Sateesh_Kambhampati\\Desktop\\React_Projects\\nextjs_learn\\pages\\_error.js?entry";

var errorPage = function errorPage() {
  return _react2.default.createElement("div", {
    className: "jsx-212487067" + " " + "error",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 4
    }
  }, _react2.default.createElement("p", {
    className: "jsx-212487067",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 5
    }
  }, "Oops something went wrong!"), _react2.default.createElement("p", {
    className: "jsx-212487067",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, "Please click here to go ", _react2.default.createElement(_link2.default, { href: "/auth", __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, _react2.default.createElement("a", {
    className: "jsx-212487067",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, "Back")), " "), _react2.default.createElement(_style2.default, {
    styleId: "212487067",
    css: "div.error.jsx-212487067{border:1px solid red;padding:20px;text-align:center;box-shadow:0 2px 3px #ccc;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2VzXFxfZXJyb3IuanM/ZW50cnkiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBTWdCLEFBRytCLHFCQUNMLGFBQ0ssa0JBQ1EsMEJBQ2hDIiwiZmlsZSI6InBhZ2VzXFxfZXJyb3IuanM/ZW50cnkiLCJzb3VyY2VSb290IjoiQzovVXNlcnMvU2F0ZWVzaF9LYW1iaGFtcGF0aS9EZXNrdG9wL1JlYWN0X1Byb2plY3RzL25leHRqc19sZWFybiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5jb25zdCBlcnJvclBhZ2UgPSAoKSA9PiAoXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJlcnJvclwiPlxyXG4gICAgPHA+T29wcyBzb21ldGhpbmcgd2VudCB3cm9uZyE8L3A+XHJcbiAgICA8cD5QbGVhc2UgY2xpY2sgaGVyZSB0byBnbyA8TGluayBocmVmPVwiL2F1dGhcIj48YT5CYWNrPC9hPjwvTGluaz4gPC9wPlxyXG4gICAgPHN0eWxlIGpzeD57YFxyXG4gICAgICBkaXYuZXJyb3Ige1xyXG4gICAgICAgICBib3JkZXI6IDFweCBzb2xpZCByZWQ7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogMCAycHggM3B4ICNjY2M7XHJcbiAgICAgIH1cclxuICAgIGB9PC9zdHlsZT5cclxuICA8L2Rpdj4gIFxyXG4pO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZXJyb3JQYWdlOyJdfQ== */\n/*@ sourceURL=pages\\_error.js?entry */"
  }));
};

exports.default = errorPage;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2VzXFxfZXJyb3IuanMiXSwibmFtZXMiOlsiUmVhY3QiLCJMaW5rIiwiZXJyb3JQYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsQUFBTzs7OztBQUNQLEFBQU87Ozs7Ozs7O0FBQ1AsSUFBTSxZQUFZLFNBQVosQUFBWSxZQUFBO3lCQUNoQixjQUFBO3VDQUFBLEFBQWU7O2dCQUFmO2tCQUFBLEFBQ0U7QUFERjtBQUFBLEdBQUEsa0JBQ0UsY0FBQTtlQUFBOztnQkFBQTtrQkFBQTtBQUFBO0FBQUEsS0FERixBQUNFLEFBQ0EsK0NBQUEsY0FBQTtlQUFBOztnQkFBQTtrQkFBQTtBQUFBO0FBQUEsS0FBMkIsNENBQUEsQUFBQyxnQ0FBSyxNQUFOLEFBQVc7Z0JBQVg7a0JBQUEsQUFBbUI7QUFBbkI7cUJBQW1CLGNBQUE7ZUFBQTs7Z0JBQUE7a0JBQUE7QUFBQTtBQUFBLEtBQTlDLEFBQTJCLEFBQW1CLFVBRmhELEFBRUU7YUFGRjtTQURnQixBQUNoQjtBQUFBO0FBREYsQUFlQTs7a0JBQUEsQUFBZSIsImZpbGUiOiJfZXJyb3IuanM/ZW50cnkiLCJzb3VyY2VSb290IjoiQzovVXNlcnMvU2F0ZWVzaF9LYW1iaGFtcGF0aS9EZXNrdG9wL1JlYWN0X1Byb2plY3RzL25leHRqc19sZWFybiJ9

 ;(function register() { /* react-hot-loader/webpack */ if (true) { if (typeof __REACT_HOT_LOADER__ === 'undefined') { return; } /* eslint-disable camelcase, no-undef */ var webpackExports = typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__ : module.exports; /* eslint-enable camelcase, no-undef */ if (typeof webpackExports === 'function') { __REACT_HOT_LOADER__.register(webpackExports, 'module.exports', "C:\\Users\\Sateesh_Kambhampati\\Desktop\\React_Projects\\nextjs_learn\\pages\\_error.js"); return; } /* eslint-disable no-restricted-syntax */ for (var key in webpackExports) { /* eslint-enable no-restricted-syntax */ if (!Object.prototype.hasOwnProperty.call(webpackExports, key)) { continue; } var namedExport = void 0; try { namedExport = webpackExports[key]; } catch (err) { continue; } __REACT_HOT_LOADER__.register(namedExport, key, "C:\\Users\\Sateesh_Kambhampati\\Desktop\\React_Projects\\nextjs_learn\\pages\\_error.js"); } } })();
    (function (Component, route) {
      if (false) return
      if (false) return

      var qs = __webpack_require__(84)
      var params = qs.parse(__resourceQuery.slice(1))
      if (params.entry == null) return

      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/_error")
  
/* WEBPACK VAR INJECTION */}.call(exports, "?entry"))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMS5mMTcxMDgyYmVkZTcxM2ViYTQ4MS5ob3QtdXBkYXRlLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vcGFnZXMvX2Vycm9yLmpzP2JlYTk3ZTYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmNvbnN0IGVycm9yUGFnZSA9ICgpID0+IChcclxuICA8ZGl2IGNsYXNzTmFtZT1cImVycm9yXCI+XHJcbiAgICA8cD5Pb3BzIHNvbWV0aGluZyB3ZW50IHdyb25nITwvcD5cclxuICAgIDxwPlBsZWFzZSBjbGljayBoZXJlIHRvIGdvIDxMaW5rIGhyZWY9XCIvYXV0aFwiPjxhPkJhY2s8L2E+PC9MaW5rPiA8L3A+XHJcbiAgICA8c3R5bGUganN4PntgXHJcbiAgICAgIGRpdi5lcnJvciB7XHJcbiAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHJlZDtcclxuICAgICAgICAgICAgcGFkZGluZzogMjBweDtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiAwIDJweCAzcHggI2NjYztcclxuICAgICAgfVxyXG4gICAgYH08L3N0eWxlPlxyXG4gIDwvZGl2PiAgXHJcbik7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBlcnJvclBhZ2U7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vcGFnZXMvX2Vycm9yLmpzP2VudHJ5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTs7O0FBQUE7QUFDQTs7Ozs7OztBQUFBO0FBQ0E7QUFBQTs7QUFBQTtBQUNBO0FBREE7QUFBQTtBQUNBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkE7QUFBQTtBQUFBO0FBY0E7QUFDQTtBQURBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0EiLCJzb3VyY2VSb290IjoiIn0=