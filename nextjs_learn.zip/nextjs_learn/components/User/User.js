import React from "react";

const User = (props) => ( 
   <div>
     <h3>Name: {props.name} </h3>
     <p>Age: {props.age} </p>
   </div>
);

export default User;