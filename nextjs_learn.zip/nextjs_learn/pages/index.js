import React from "react";
import Link from "next/link";
import Router from "next/router";

const indexPage = () => (
  <div>
    <div>Welcome to next js</div>
    Click here to go to <Link href="/auth"><a>Auth</a></Link> Page
    <button onClick = {() => Router.push("/auth/index") } >Go to Auth</button>
  </div>
)
export default indexPage;