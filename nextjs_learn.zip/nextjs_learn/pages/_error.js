import React from "react";
import Link from "next/link";
const errorPage = () => (
  <div className="error">
    <p>Oops something went wrong!</p>
    <p>Please click here to go <Link href="/auth"><a>Back</a></Link> </p>
    <style jsx>{`
      div.error {
         border: 1px solid red;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 3px #ccc;
      }
    `}</style>
  </div>  
);

export default errorPage;