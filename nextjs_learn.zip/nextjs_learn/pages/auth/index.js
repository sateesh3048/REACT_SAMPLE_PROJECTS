import React from "react"
import User from '../../components/User/User';
const indexPage = () => (
  <div id="user">
    <div>Welcome to auth users js</div>
    <User name="Sateesh" age="32" />
    <style jsx>{`
          div#user{
            border: 1px solid grey;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 3px #ccc;
          }
        `}</style>
  </div>
)
export default indexPage;