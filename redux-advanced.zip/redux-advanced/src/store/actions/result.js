import * as actionTypes from './actionTypes';
const saveResult = (res) => {
   return {
        type: actionTypes.STORE_RESULT, 
        result: res
      }
}



export const storeResult = (cur_result) => {
  return (dispatch, getState) => {
    setTimeout(() => {
      const oldCounter = getState().ctr.counter;
      console.log("Old counter valuer" + oldCounter);
      dispatch(saveResult(cur_result))
    },2000)    
  }
};

export const deleteResult = (result_id) => {
  return {
    type: actionTypes.DELETE_RESULT, 
    resultElId: result_id
  }
};

