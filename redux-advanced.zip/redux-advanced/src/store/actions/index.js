export {
  increment,
  decrement,
  add,
  subtract
} from './counter';

export {
  saveResult,
  storeResult,
  deleteResult
} from './result';
