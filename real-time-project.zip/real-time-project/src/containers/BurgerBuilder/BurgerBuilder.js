import React, {Component} from "react";
import Aux from '../../hoc/Aux';
import Burger from "../../components/Burger/Burger";
import BuildControls from "../../components/Burger/BuildControls/BuildControls"; 
import Modal from "../../UI/Modal/Modal";
import OrderSummary from "../../components/Burger/OrderSummary/OrderSummary";

const INGREDIENT_PRICES = {
      salad: 0.6,
      bacon: 0.8,
      cheese: 0.5,
      meat: 1.5
}
class BurgerBuilder extends Component {
  
  state = {
    ingredients: {
      salad: 0,
      bacon: 0,
      cheese: 0,
      meat: 0
    },
    totalPrice: 4,
    purcheasable: false,
    purchasing: false
  }

  updatePurchasePrice = () => {
    const ingredients = this.state.ingredients;
    const sum = Object.keys(ingredients)
      .map((igKey) => ingredients[igKey])
      .reduce(((sum, ele) => sum+ele), 0);
    console.log("recent sum"+sum);
    console.log(ingredients);
    this.setState({purcheasable: sum > 0})
  }

  addIngredientHandler = (type) => {
    console.log("I am in addIngredientHandler");
    console.log(type);

    /* Updating Ingredients */
    const oldCount = this.state.ingredients[type];
    console.log("oldCount"+oldCount);
    const updatedCount = oldCount + 1;
    console.log("updatedCount"+updatedCount);
    const updatedIngredients = {...this.state.ingredients};
    updatedIngredients[type] = updatedCount;
    
    /* Updating Price */
    const oldPrice = this.state.totalPrice;
    const itemPrice = INGREDIENT_PRICES[type];
    const newPrice = oldPrice + itemPrice;

    console.log("updatedIngredients>>updatedIngredients");
    console.log(updatedIngredients);
    console.log(newPrice);

    /* Updating state */ 
    this.setState({
      ingredients: updatedIngredients,
      totalPrice: newPrice
    }, this.updatePurchasePrice)

  }

  removeIngredientHandler = (type) => {
    console.log("removeIngredientHandler");
    console.log("type:"+type);
    
    const oldCount = this.state.ingredients[type];
    console.log("oldCount"+oldCount);
    if(oldCount <= 0){
      return;
    }
    const updatedCount = oldCount - 1;
    console.log("updateCount"+ updatedCount);

    const updatedIngredients = {...this.state.ingredients};
    updatedIngredients[type] = updatedCount;

    /* Updating Price */
    const oldPrice = this.state.totalPrice;
    const itemPrice = INGREDIENT_PRICES[type];
    const newPrice = oldPrice - itemPrice;

    /* Update state */
    this.setState({
      ingredients: updatedIngredients,
      totalPrice: newPrice
    }, this.updatePurchasePrice)
  }

  showModalHandler = () => {
    this.setState({
      purchasing: true
    })
  }

  purchaseCancelHandler = () => {
     this.setState({
      purchasing: false
    })
  }

  purchaseContinueHandler = () => {
    alert("Are you sure want to continue ?");
  }
 


  render(){
    console.log("purcheasable>>>purcheasable");
    console.log(this.state.purcheasable);

    const disabledIngredients = {...this.state.ingredients};
    
    for(let key in disabledIngredients){
      disabledIngredients[key] = disabledIngredients[key] <= 0
    }

    console.log("disabledIngredients>>disabledIngredients");
    console.log(disabledIngredients);
    
    return (
      <Aux>
        <Modal show= {this.state.purchasing} modalClosed={this.purchaseCancelHandler}>
          <OrderSummary 
             ingredients = {this.state.ingredients }
             purchaseCancelled = {this.purchaseCancelHandler}
             purchaseContinue = {this.purchaseContinueHandler}
             price = {this.state.totalPrice.toFixed(2)}
          />
        </Modal> 
        <Burger ingredients = {this.state.ingredients} />
        <BuildControls 
          addIngredientHook = {this.addIngredientHandler} 
          removeIngredientHook = {this.removeIngredientHandler} 
          disableIngredients = {disabledIngredients} 
          price = {this.state.totalPrice } 
          isPurcheasable = {this.state.purcheasable} 
          purchasing={this.showModalHandler}
          />
      </Aux>
    );
  }
}

export default BurgerBuilder;