import React from "react";
import classes from "./BuildControls.css";
import BuildControl from "./BuildControl/BuildControl";

const Controls = [
  { label: "Salad", type: "salad" },
  { label: "Cheese", type: "cheese" },
  { label: "Meat", type: "meat" },
  { label: "Bacon", type: "bacon" }  
];

const buildControls = (props) => (
  <div className={classes.BuildControls}>
    <div>Price: <strong>${props.price.toFixed(2)}</strong> </div>
    {Controls.map(ctrl => (
      <BuildControl key={ctrl.label} label={ctrl.label} 
        moreIngredientsHook = {() => props.addIngredientHook(ctrl.type)} 
        lessIngredientsHook = {() => props.removeIngredientHook(ctrl.type)} 
        disabled = { props.disableIngredients[ctrl.type] }
      />
    ))}
    <button className={classes.OrderButton} 
    disabled={!props.isPurcheasable} 
    onClick={props.purchasing}
    >ORDER NOW</button>
  </div>
);

export default buildControls;