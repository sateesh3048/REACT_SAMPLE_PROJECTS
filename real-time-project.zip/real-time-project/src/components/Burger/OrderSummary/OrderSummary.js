import React from "react";
import Aux from '../../../hoc/Aux';
import Button from '../../../UI/Button/Button';

const orderSummary = (props) => {
   const ingredientSummary = Object.keys(props.ingredients).map((igKey) => {
          return(
            <li key={igKey} >
                <span style={{textTransform: 'capitalize'}}>{igKey}</span>: {props.ingredients[igKey]}
            </li>)
        });
  return(
    <div>
      <ul>
        {ingredientSummary}
      </ul>
      <p>
        <strong>Total Price: {props.price} </strong>
      </p>
     <p>Continue to checkout ?</p>
      <Button btnType="Danger" btnClicked={props.purchaseCancelled}>Cancel</Button>
      <Button btnType="Success" btnClicked={props.purchaseContinue}>Continue</Button>
    </div>
  )
}
export default orderSummary;