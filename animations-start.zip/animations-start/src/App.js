import React, { Component } from "react";
import Transition from "react-transition-group/Transition";
import "./App.css";
import Modal from "./components/Modal/Modal";
import Backdrop from "./components/Backdrop/Backdrop";
import List from "./components/List/List";
import { CSSTransition, TransitionGroup } from 'react-transition-group'


class App extends Component {
  
  

  state = {
    modalIsOpen: false,
    backdropShow: false,
    showBlock: false
  };

  showModalHandler = () => {
    this.setState({
      modalIsOpen: true
    })
  };

  hideModalHandler = () => {
  this.setState({
      modalIsOpen: false
    })
  }

  render() {
    const animationTiming = {
      enter: 400,
      exit: 1000
    };

    return (
      <div className="App">
      <h1>React Animations</h1>
      <button 
          onClick= {() => 
          this.setState(prevState => ({showBlock: !prevState.showBlock}))}
      >
        Toggle Button
      </button>
      <Transition 
        in={this.state.showBlock} 
        mountOnEnter
        unmountOnExit
        timeout={animationTiming}
        mountOnEnter
        unmountOnExit
        onEnter = { () => console.log("On Enter")}
        onEntering = { () => console.log("On Entering")}
        onEntered = { () => console.log("On Entered")}
        onExit = { () => console.log("On Exit")}
        onExiting = {() => console.log("On Exiting")}
        onExited = {() => console.log("On Exited")}
      >  
        <div
          style= {{
            
            backgroundColor: "red",
            width: 100,
            height: 100,
            padding: "10px"
          }}
        >

        </div>
      </Transition> 
      <CSSTransition 
        classNames="fade-in"
        mountOnEnter
        unmountOnExit
        in={this.state.modalIsOpen}
        timeout={300}
      >
        { state => (
          <Modal show={state} closed={this.hideModalHandler}/>
        )}
      </CSSTransition>
        <Backdrop show={this.state.modalIsOpen} /> 
        <button className="Button" onClick={this.showModalHandler}>Open Modal</button>
        <h3>Animating Lists</h3>
        <List />
      </div>
    );
  }
}

export default App;
