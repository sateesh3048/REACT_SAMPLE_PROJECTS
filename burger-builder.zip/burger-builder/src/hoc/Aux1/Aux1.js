const Aux11 = (props) => props.children;

export default Aux11;