import axios from "axios";
//import React from "react";

const instance = axios.create({
  baseURL: 'https://react-burger-builder-3962c.firebaseio.com/'
});

export default instance;