import React, { Component } from "react";
import Input from '../../components/UI/Forms/Input/Input';
import Button from '../../components/UI/Button/Button';
import classes from './Auth.css';
import * as actions from '../../store/actions/index';
import {connect} from 'react-redux';
import Spinner from '../../components/UI/Spinner/Spinner';
import { Redirect } from "react-router-dom";

class Auth extends Component {
  state = {
    isSignup: true,
    isCheckout: false,
    controls: {
      email: {
        elementType: 'input',
        elementConfig: {
          type: 'email',
          placeholder: "Your email Address"
        },
        value: '',
        validation: {
          required: true,
          isEmail: true
        },
        valid: false,
        touched: false
      },
      password: {
        elementType: 'input',
        elementConfig: {
          type: 'password',
          placeholder: "Enter Password"
        },
        value: '',
        validation: {
          required: true,
          minLength: 6,
          isEmail: true
        },
        valid: false,
        touched: false
      }
    }
  }
  
  checkValidaty = (value, rules) => {
    let isValid = true;
    if(rules.exactLength){
      isValid = (value.length === rules.exactLength) && isValid;
    }
    if(rules.required){
      isValid = (value.trim() !== '') && isValid; 
    }
    return isValid;
  }

  componentDidMount(){
    const query = new URLSearchParams(this.props.location.search);
    console.log("query.get('checkout')");
    console.log(query.get('checkout'));
    const is_checkout = query.get('checkout');
    console.log(is_checkout);

    this.setState({isCheckout: is_checkout});
    console.log("After checkout");
    console.log(this.state.isCheckout);
  }

  inputChangedHanlder = (event, controlName) => {
    let updatedControls = { 
        ...this.state.controls,
        [controlName]: {
          ...this.state.controls[controlName],
          value: event.target.value,
          valid:  this.checkValidaty(event.target.value, this.state.controls[controlName].validation),
          touched: true
        }
    }
    
    //console.log(formIsValid);
    this.setState({controls: updatedControls});
  }
  
  submitHandler = (event) => {
    event.preventDefault();
    const authType = this.state.isSignup? "SignUp" : "SignIn";
    this.props.onAuth(this.state.controls.email.value, this.state.controls.password.value, authType);
  }

  switchauthModeHandler = () => {
    this.setState(preveState => {
      return {isSignup: !preveState.isSignup};
    })
  }

  render() {

    let authRedirect = null;
    if(this.props.isAuthenticated && this.state.isCheckout){
      authRedirect = <Redirect to="/checkout" />
    }else if(this.props.isAuthenticated){
      //console.log("current token");
      //console.log(this.props.token);
      authRedirect = <Redirect to="/" />
    }

    const formElementsArray = [];
    let spinnerUI = null;
    let errorUI = null;
    if(this.props.error){
      errorUI = <p>{this.props.error.message}</p>
    }
    
    if(this.props.loading){
      spinnerUI = <Spinner />  
    }

    for(let key in this.state.controls){
      formElementsArray.push({
        id: key,
        config: this.state.controls[key]
      });
    }

    const formElementsUI = formElementsArray.map(formElement => (
      <Input 
        key={formElement.id} 
        elementType={formElement.config.elementType}  
        elementConfig={formElement.config.elementConfig}
        value={formElement.config.value}
        invalid = { !formElement.config.valid }
        shouldValidate = { formElement.config.validation.required }
        touched = {formElement.config.touched}
        validationErrorMsg = {formElement.config.validation.errorMsg}
        changed = {(event) => this.inputChangedHanlder(event, formElement.id) }
      />
    ))
    return (
      <div className={classes.Auth}>
        {authRedirect}
        {spinnerUI}
        {errorUI}
        <form onSubmit={this.submitHandler}>
          {formElementsUI}
          <Button btnType="Success">Submit</Button>
        </form>
        <Button 
          btnType="Danger" 
          clicked={this.switchauthModeHandler}> 
          Switch to {this.state.isSignup ? "SIGNIN" : "SIGNUP"}
        </Button>
      </div>
    )
  }
}


const mapStateToProps = state => {
  return {
    loading: state.auth.loading,
    error: state.auth.err,
    token: state.auth.token,
    isAuthenticated: state.auth.token !== null
  }
};

const mapDispatchToProps = dispatch => {
  return {
    onAuth: (email, password, authType) => dispatch(actions.auth(email, password, authType))
  }
};


export default connect(mapStateToProps, mapDispatchToProps)(Auth);