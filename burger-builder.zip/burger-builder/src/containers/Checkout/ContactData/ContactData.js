import React, {Component} from 'react';
import Button from  '../../../components/UI/Button/Button';
import classes from './ContactData.css';
import axios from '../../../axios-orders';
import Spinner from '../../../components/UI/Spinner/Spinner';
import Input from '../../../components/UI/Forms/Input/Input';
import {connect} from 'react-redux';
import * as actionCreators from '../../../store/actions/index';
import withErrorHandler  from  '../../../hoc/withErrorHandler/withErrorHandler';

class ContactData extends Component {
  state = {
    formIsValid: true,
    orderForm: {
      name: {
        elementType: 'input',
        elementConfig: {
          type: "text",
          placeholder:  'Enter your Name'
        },
        value: '',
        validation: {
          required: true,
          errorMsg: "Please enter your name"
        },
        valid: false,
        touched: false
      },
      street:  {
        elementType: 'input',
        elementConfig: {
          type: "text",
          placeholder: "Enter your Street"
        },
        value: "",
        validation: {
          required: true,
          errorMsg: "Please enter your name"
        },
        valid: false,
        touched: false
      },
      zipcode: {
        elementType: 'input',
        elementConfig: {
          type: "text",
          placeholder: "Please Enter your zipcode with 5 digits"
        },
        value: "",
        validation: {
          required: true,
          exactLength: 5,
          errorMsg: "Please Enter your zipcode with 5 digits"
        },
        valid: false,
        touched: false
      },
      country: {
        elementType: 'input',
        elementConfig: {
          type: "text",
          placeholder: "Enter your country"
        },
        value: "",
        validation: {
          required: true,
          errorMsg: "Please enter your country"
        },
        valid: false,
        touched: false
      },
      email: {
        elementType: 'input',
        elementConfig: {
          type: "email",
          placeholder: "Enter your E-mail"
        },
        value: "",
        validation: {
          required: true,
          errorMsg: "Please enter your Email"
        },
        valid: false,
        touched: false
      },
      deliveryMethod: {
        elementType: 'select',
        elementConfig: {
          options: [
            {value: 'fastest', displayValue: 'Fastest'},
            {value: 'cheapest', displayValue: 'Cheapest'}
          ]
        },
        value: 'cheapest',
        valid: true,
        validation: {
          required: false
        },   
      }
    }
  }

  orderHandler = (event) => {
    event.preventDefault();
    const formData = {};
    for(let formElementIdentifier in this.state.orderForm){
      formData[formElementIdentifier] = this.state.orderForm[formElementIdentifier].value;
    }

    //this.setState({loading: true});
     const order = {
            ingredients: this.props.ings,
            price: this.props.price,
            orderData: formData
        }
        
        this.props.onOrderBurger(order, this.props.token);
  } 

  inputChangedHanlder = (event, inputIdentifier) => {
    console.log(event.target.value);
    let updatedOrderForm = { 
        ...this.state.orderForm
    }
    let updatedFormElement = {
      ...updatedOrderForm[inputIdentifier]
    }
    updatedFormElement.value = event.target.value;
    updatedFormElement.valid = this.checkValidaty(updatedFormElement.value, updatedFormElement.validation)
    updatedFormElement.touched = true
    updatedOrderForm[inputIdentifier] = updatedFormElement;
    let formIsValid = true;
    
    for(let formElement in updatedOrderForm){
      formIsValid = updatedOrderForm[formElement].valid && formIsValid
    }
    
    //console.log(formIsValid);
    this.setState({orderForm: updatedOrderForm, formIsValid: formIsValid});
  }

  checkValidaty = (value, rules) => {
    let isValid = true;
    if(rules.exactLength){
      isValid = (value.length === rules.exactLength) && isValid;
    }
    if(rules.required){
      isValid = (value.trim() !== '') && isValid; 
    }
    return isValid;
  }

  render(){
    console.log("testing >>> contact data");
    let formElementsArray = [];
    for(let key in this.state.orderForm){
      formElementsArray.push({
        id: key,
        config: this.state.orderForm[key]
      })
    }
    let form = 
        <form onSubmit={this.orderHandler}>
          {formElementsArray.map(formElement => (
            <Input 
              key={formElement.id} 
              elementType={formElement.config.elementType}  
              elementConfig={formElement.config.elementConfig}
              value={formElement.config.value}
              invalid = { !formElement.config.valid }
              shouldValidate = { formElement.config.validation.required }
              touched = {formElement.config.touched}
              validationErrorMsg = {formElement.config.validation.errorMsg}
              changed = {(event) => this.inputChangedHanlder(event, formElement.id) }
              />
            ))
          }
          <Button btnType="Success" disabled={!this.state.formIsValid}>ORDER</Button>
        </form>
       if(this.props.loading){
         form = <Spinner />
       }
    return (
      <div className={classes.ContactData}>
        <h4>Enter your contact data</h4>
        {form}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    ings: state.burgerBuilder.ingredients,
    price: state.burgerBuilder.totalPrice,
    loading: state.order.loading,
    token: state.auth.token
  }
};

const mapDispatchToProps = dispatch => {
  return {
    onOrderBurger: (orderData, auth_token) => dispatch(actionCreators.purchaseBurger(orderData, auth_token))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(withErrorHandler(ContactData, axios));