import React, {Component} from "react";
import CheckoutSummary from "../../components/Order/CheckoutSummary/CheckoutSummary";
import { Route, Redirect } from 'react-router-dom';
import ContactData from './ContactData/ContactData';
import { connect } from 'react-redux';
import * as actions from '../../store/actions/index';

class Checkout extends Component {
  
  state = {
    continueCheckout: false
  }
  
  componentWillMount(){
  //  this.props.onPurchaseInit();
  }
  

  /*state = {
    ingredients: null,
    price: 0
  }

  componentWillMount(){
    console.log("Reading query parameters");
    console.log(qs.parse(this.props.location.search));
    const ingredients =  qs.parse(this.props.location.search);
    console.log(ingredients);
    let price = ingredients.price;
    delete ingredients.price
    console.log(price);
    this.setState({
      ingredients: ingredients,
      price: price
    })
  }*/

  checkoutCancelledHandler = () => {
    this.props.history.goBack();
  }

  checkoutContinuedHandler = () => {
    this.setState({
      continueCheckout: true
    })
    this.props.history.replace("/checkout/contact-data");
  }

  render(){
    let summary = <Redirect to="/" />;
    let contactDatRoute =  (
          <Route 
            to = {this.props.match.url + "/contact-data"}  
            component={ContactData}/>
          );
    if(this.props.ings){
      const checkoutRedirect = <Redirect to="/" />;
      summary = (
        <div>
          {this.props.purchased ? checkoutRedirect : null}
          <CheckoutSummary 
            ingredients={this.props.ings} 
            checkoutCancelled = { this.checkoutCancelledHandler }
            checkoutContinued = { this.checkoutContinuedHandler }
          />
          {
            this.state.continueCheckout ?  contactDatRoute : null
          }
        </div>
      )
    }
    return summary;
  }
}

const mapStateToProps = state => {
  return {
    ings: state.burgerBuilder.ingredients,
    price: state.burgerBuilder.totalPrice,
    purchased: state.order.purchased
  }
};

const mapDispatchToProps = dispatch => {
  return {
    onPurchaseInit: () => dispatch(actions.purchaseInit())
  }
}


export default connect(mapStateToProps, mapDispatchToProps)(Checkout);