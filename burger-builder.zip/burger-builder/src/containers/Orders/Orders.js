import React, {Component} from "react";
import Order from '../../components/Order/Order';
import axios from '../../axios-orders';
import withErrorHandler from '../../hoc/withErrorHandler/withErrorHandler';
import {connect} from 'react-redux';
import * as actions from '../../store/actions/index';
import Spinner from '../../components/UI/Spinner/Spinner';

class Orders extends Component {
/*  state = {
    orders: [],
    loading: true
  }*/
  componentDidMount(){
    console.log("Auth toke value from orders container");
    console.log(this.props.token);
    this.props.onFetchOrders(this.props.token);
    /*axios.get("/orders.json")
    .then((response) => {
        const fetchedOrders = [];
        for(let key in response.data){
          fetchedOrders.push({
            ...response.data[key],
            id: key
          })
        }
        console.log("Orders#List");
        console.log(response.data);
        this.setState({orders: fetchedOrders, loading: false})
    })
    .catch(err => {
      this.setState({loading: false})
    })*/
  }
  render(){
    let ordersUI = <Spinner />;
    if(this.props.orders){
      let orders = this.props.orders;

      ordersUI = orders.map(order => {
        return <Order 
          ingredients = {order.ingredients}
          price = {order.price}
          key = {order.id}
        />
      })

    }
    
    console.log("ordersUI>>>ordersUI");
    console.log(ordersUI);   
    return(
      <div>
        { ordersUI }
      </div>
    )
  }
}

  const mapStateToProps = state => {
    return {
      orders: state.order.orders,
      loading: state.order.loading,
      token: state.auth.token
    }
  }

  const mapDispatchToProps = dispatch => {
    return {
      onFetchOrders: (auth_token) =>  dispatch(actions.fetchOrders(auth_token))
    }
  }

export default connect(mapStateToProps, mapDispatchToProps)(withErrorHandler(Orders, axios)); 