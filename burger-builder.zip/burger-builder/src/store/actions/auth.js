import * as actionTypes from './actionTypes';
import axios from 'axios';

export const syncAuthStart = () => {
  return {
    type: actionTypes.AUTH_START
  };
};


export const syncAuthSuccess = (authData) => {
  return {
    type: actionTypes.AUTH_SUCCESS,
    authData: authData
  };
};

export const syncAuthFail = (error) => {
  return {
    type: actionTypes.AUTH_FAIL,
    error: error
  };
};

export const syncLogout = () => {
  //clearItemsFromLocalStorage();
  return {
    type: actionTypes.AUTH_INITIATE_LOGOUT
  };
};


export const manualLogout = () => {
  return dispatch => {
    dispatch(syncLogout());
  }
}

export const authAutoLogout = () => {
  let expirationDate = localStorage.getItem("expirationDate");
  const expirationTime = new Date(expirationDate).getTime();
  const currentTime = new Date().getTime();
  const duration = ((expirationTime-currentTime)/1000);
  return dispatch => {
    setTimeout(() => {
      dispatch(syncLogout());
    }, duration*1000);
  };
};

export const syncAuthVerifyLogin = (token, userId) => {
  return {
    type: actionTypes.AUTH_VERIFY_LOGIN,
    token: token,
    userId: userId
  };
};

export const authValidateLogin = () => {
  return dispatch => {
    const token = localStorage.getItem("token");
    const userId = localStorage.getItem("userId");
    if(token){
      dispatch(syncAuthVerifyLogin(token, userId));
    }else{
      dispatch(syncLogout());
    }
  };
};

export const setItemsInLocalStorage = (token, userId, expirationDate) => {
    localStorage.setItem("token", token);
    localStorage.setItem("userId", userId);
    localStorage.setItem("expirationDate", expirationDate);
};

export const clearItemsFromLocalStorage = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("expirationDate");
  localStorage.removeItem("userId");
};

export const auth = (email, password, authType) => {
  const apiKey = 'AIzaSyAdcFhMqKQesHmpF1a5CQVVrMMeb7ANWWA';

  let url = `https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser?key=${apiKey}`;

  if(authType ==='SignIn'){
    url = `https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key=${apiKey}`;
  }

  return dispatch => {
    dispatch(syncAuthStart());
    const authParams = {
      email: email,
      password: password,
      returnSecureToken: true
    }
    axios.post(url, authParams)
    .then(response => {
      const authData = {
        idToken: response.data.idToken,
        userId: response.data.localId
      };
      const expirationDate = new Date(new Date().getTime() + 1000*(response.data.expiresIn));
      setItemsInLocalStorage(response.data.idToken, response.data.localId, expirationDate);
      dispatch(syncAuthSuccess(authData));
      dispatch(authAutoLogout());
    })
    .catch(err => {
       dispatch(syncAuthFail(err.response));
    })
  };
};
