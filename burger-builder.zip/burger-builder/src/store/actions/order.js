import * as actionTypes from './actionTypes';
import axios from '../../axios-orders';

export const purchaseBurgerSuccess = (id, orderData) => {
  return {
    type: actionTypes.PURCHASE_BURGER_SUCCESS,
    orderId: id,
    orderData: orderData
  };
};

export const purchaseBurgerFail = (error) => {
  return {
    type: actionTypes.PURCHASE_BURGER_FAIL,
    error: error
  };
};

export const  purchaseBurgerStart = () => {
  return {
    type: actionTypes.PURCHASE_BURGER_START,
    loading: true
  };
};

export const purchaseBurger = (orderData, auth_token) => {
  return dispatch => {
    dispatch(purchaseBurgerStart());
    axios.post(`/orders.json?auth=${auth_token}`, orderData)
              .then(response => {
                //this.setState({loading: false, purchasing: false});  
                console.log("purchaseBurger>>>purchaseBurger");
                console.log(response);
                //this.props.history.push("/");
                dispatch(purchaseBurgerSuccess(response.data.name, orderData))
                }) 
              .catch(error => {
                  //this.setState({loading: false, purchasing: false});  
                  console.log(error)
                  dispatch(purchaseBurgerFail(error))
              });
  };
};

export const purchaseInit = () => {
  return {
    type: actionTypes.PURCHASE_INIT
  }
}

export const loadOrders = (orders) => {
  return {
    type: actionTypes.FETCH_ORDERS_SUCCESS,
    orders: orders
  }
}


export const handleLoadOrdersFail = () => {

};


export const fetchOrdersInit = () => {
  return {
    type: actionTypes.FETCH_ORDERS_INIT,
    loading: true
  };
};

export const fetchOrdersFail = (error) => {
  return {
    type: actionTypes.FETCH_ORDERS_FAIL,
    loading: false,
    error: error
  }
}



export const  fetchOrders = (auth_token) => {
  console.log("auth_token>>>>>>from fetch orders");
  console.log(auth_token);
  return dispatch => {
    console.log("Calling Loading image from fetchOrdersInit");
    dispatch(fetchOrdersInit());
    axios.get(`/orders.json?auth=${auth_token}`)
    .then((response) => {
        const fetchedOrders = [];
        for(let key in response.data){
          fetchedOrders.push({
            ...response.data[key],
            id: key
          })
        }
        console.log("Orders#List");
        console.log(response.data);
        setTimeout(()=> {
          dispatch(loadOrders(fetchedOrders))
        },2000) 
        //this.setState({orders: fetchedOrders, loading: false})
    })
    .catch(err => {
      dispatch(fetchOrdersFail(err))
    })
    
  }
}