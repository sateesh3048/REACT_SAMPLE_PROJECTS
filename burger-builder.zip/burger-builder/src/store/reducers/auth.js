import * as actionTypes from '../actions/actionTypes';
import {updateObject} from './utility';

const initialState = {
  token: null,
  userId: null,
  err: null,
  loading: false
};

const authStart = (state, action) => {
  return updateObject(state, {loading: true, err: null});
};

const authSuccess = (state, action) => {
  console.log("authSuccess Action");
  console.log(action);
  console.log(state);
  const updateIdToken = {
    token: action.authData.idToken,
    userId: action.authData.userId,
    err: null,
    loading: false
  };
  console.log("updateIdToken______updateIdToken");
  console.log(updateIdToken);
  return updateObject(state, updateIdToken);
};

const authFail = (state, action) => {
  return updateObject(state, {err: action.error, loading: false});
};

const authLogout = (state, action) => {
  return updateObject(state, {token: null, userId: null, err: null,loading: false});
};

const authVerifyLogin = (state, action) => {
  console.log("i am from authVerifyLogin");
  return updateObject(state, {token: action.token});
}

const reducer = (state=initialState, action) => {
  switch(action.type){
    case actionTypes.AUTH_START: return authStart(state, action);
    case actionTypes.AUTH_SUCCESS: return authSuccess(state, action);
    case actionTypes.AUTH_FAIL: return authFail(state, action);
    case actionTypes.AUTH_LOGOUT: return authLogout(state, action);
    case actionTypes.AUTH_VERIFY_LOGIN: return authVerifyLogin(state, action);
    default: return state;
  }
}

export default reducer;