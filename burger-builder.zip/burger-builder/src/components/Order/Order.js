import React from "react";
import classes from "./Order.css";
const order = (props) => {
  
  const ingredientsDescription = () => {
    let ingredientsUI = [];
    for(let [name, quantity] of Object.entries(props.ingredients)){
      ingredientsUI.push(<span 
        key={name} 
        style={{
          textTransform: "capitalize",
          margin: "0px 8px",
          display: "inline-block",
          border: "1px solid #ccc",
          padding: "5px",
        }}>
          {name} ({quantity})
      </span>)
    }
    return ingredientsUI;
  }  
    return( 
      <div className={classes.Order}>
        <p>Ingredients: {ingredientsDescription()}</p>
        <p>Price: <strong>USD {props.price}</strong></p>
      </div>
  )
};

export default order; 