import React from 'react';

import classes from './NavigationItems.css';
import NavigationItem from './NavigationItem/NavigationItem';

const navigationItems = (props) => (
        <div>
          { props.isAuthenticated ?
            <ul className={classes.NavigationItems}>
              <NavigationItem link="/" exact>Burger Builder</NavigationItem>
              <NavigationItem link="/orders">Orders</NavigationItem>
              <NavigationItem link="/logout" exact>Logout</NavigationItem> 
            </ul>
           :
           <ul className={classes.NavigationItems}>
             <NavigationItem link="/" exact>Burger Builder</NavigationItem>
             <NavigationItem link="/auth" exact>Authentication</NavigationItem> 
           </ul>
           } 
    </div>
);

export default navigationItems;