import React, {Component} from "react";
import Post from "../../components/Post/Post";
import "./Posts.css";
import axios from 'axios';
import { Route } from "react-router-dom";
import FullPost from '../FullPost/FullPost';

// import {Link} from 'react-router-dom'; 

class Posts extends Component {
    state = {
      posts: [],
      selectedPostId: null,
      error: false
    }


      () {
     
      axios.get("https://jsonplaceholder.typicode.com/posts")
      .then(response => {
        const posts = response.data.slice(0,4);
        const updatedPosts = posts.map(post => {
            return {
                ...post,
                author: "Sateesh  "
            } 
        })  
        this.setState({posts: updatedPosts});

      });
    }


    showPostHanlder = (post_id) => {
        console.log("I am in show Post handler");
        console.log(post_id);
        this.props.history.push({pathname: "/Posts/"+post_id});
      /**/
      this.setState({selectedPostId: post_id});

    }

  render(){
      console.log("url>>url");
      console.log(this.props.match.url);
    const posts = this.state.posts;
    const postsUi = posts.map((post) => {
      return (
        <Post 
          key = {post.id }
          title={post.title} 
          author = {post.author} 
          showPost = { () => {this.showPostHanlder(post.id)} }
        />
      )
    })  
    return(
      <div>
        <section className="Posts">
            {postsUi}
        </section>
        <Route path={this.props.match.url+'/:id'}  exact component={FullPost} />
      </div>
    )
  }
}

export default Posts;