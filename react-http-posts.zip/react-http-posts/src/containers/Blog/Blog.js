import React, { Component } from 'react';
import './Blog.css';
import Posts from '../Posts/Posts';
import Post from '../../components/Post/Post';

import NewPost from '../NewPost/NewPost';
import {Route, NavLink, Switch, Redirect} from 'react-router-dom';
import FullPost from '../FullPost/FullPost';

class Blog extends Component {
    state= {
        auth: false
    }
    render () {
        return (
            <div className="Blog">
                <header>
                    <nav>
                        <ul>
                            <li><NavLink to="/Posts" exact>Posts</NavLink></li>
                            <li><NavLink to="/Posts/new-post">New Post</NavLink></li>
                        </ul>
                    </nav>
                </header>
                {/*<Route path="/" exact render={() => <Posts />} />
                <Route path="/" render={() => <footer><h2>Copy Rights Reserved!</h2></footer>} />*/} 
                <Switch>
                    {this.state.auth ? <Route path="/Posts/new-post" exact component={NewPost} /> : null } 
                    <Route path="/Posts" exact component={Posts} />
                    <Redirect exact from="/" to="/Posts" />
                    <Route render={() => <h1>Sorry Route not found</h1>} />
                    {/*<Route path="/" component={Posts} />   */}
                </Switch>
            </div>
        );
    }
}

export default Blog;