import React, { Component } from 'react';
import axios from 'axios';
import './FullPost.css';

class FullPost extends Component {
    state = {
        loadedPost: null
    }
    
    componentDidMount(){
        this.loadData();
    }

    componentDidUpdate(){
        this.loadData();

    }

    loadData = () => {
      const postId = parseInt(this.props.match.params.id);

      if(postId){
        if((!this.state.loadedPost) || (this.state.loadedPost && this.state.loadedPost.id !== postId)) {
            console.log("I am in inside");
            console.log("postId>>postId>>postId");
            console.log(this.state.loadedPost);
            console.log(postId);

            axios.get("https://jsonplaceholder.typicode.com/posts/"+postId)
            .then(response => {
                const post = response.data;
                const updatedPost = {...post, author: "Sateesh"};
                this.setState({loadedPost: updatedPost});
            })
        }
      }
    }

    DestroyPostHanlder = (post_id) => {
        if(post_id){
            axios.delete('https://jsonplaceholder.typicode.com/posts/'+post_id)
            .then(response => {
                console.log("Axios Delete Request");
                console.log(response);
            })
        }
    }

    render () {
        console.log("I am in full post render");
        let post = <p style={{textAlign: 'center'}}>Please select a Post!</p>;
        if(this.props.match.params.id){
          let post = <p style={{textAlign: 'center'}}>Loading Post!</p>;
        }
        if(this.state.loadedPost){
            post = (
                <div className="FullPost">
                    <h1>{this.state.loadedPost.title}</h1>
                    <p>{this.state.loadedPost.body}</p>
                    <div className="Edit">
                        <button className="Delete" onClick={() => { this.DestroyPostHanlder(this.state.loadedPost.id)}}>Delete</button>
                    </div>
                </div>
            );
        }
        return post;
    }
}

export default FullPost;