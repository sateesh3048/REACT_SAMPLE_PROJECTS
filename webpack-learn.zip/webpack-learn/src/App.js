import React, {Component} from 'react';
import Pizza from './containers/Pizza';
import Users from './containers/Users';
import {Route, Link} from "react-router-dom";

class App extends Component {
  render(){
    return (
      <div>
         <div>
           <Link to="/">Users</Link>
           <Link to="/pizza">Pizza</Link>
         </div>
         <div>
           <Route path="/pizza" exact component={Pizza} />
           <Route path="/" exact  component={Users}/>
         </div>
      </div>
    )
  }
}

export default App;