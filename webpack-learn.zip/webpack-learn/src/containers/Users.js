import React, {Component} from 'react';

class Users extends Component {
  render(){
    return (
      <div>
        <h1>The Users</h1>
        <p>Awesome users on board of this course!</p>
      </div>
    )
  }
}

export default Users;